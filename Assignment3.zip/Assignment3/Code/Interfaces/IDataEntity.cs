﻿namespace Assignment3
{
    public interface IDataEntity
    {
        int ID { get; set; }
        DateTime Timestamp { get; set; }
    }
}